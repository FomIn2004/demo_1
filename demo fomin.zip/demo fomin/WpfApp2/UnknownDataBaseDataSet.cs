﻿namespace WpfApp2
{
}

namespace WpfApp2
{


    public partial class UnknownDataBaseDataSet
    {
    }
}
